2 + 3 * 4          # yields 14, not 20
