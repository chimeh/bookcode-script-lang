my @ones = (1) x 80;        # a list of 80 1's
@ones = (5) x @ones;        # set all elements to 5
