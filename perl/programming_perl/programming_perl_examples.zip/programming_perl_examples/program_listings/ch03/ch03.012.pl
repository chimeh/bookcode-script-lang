$aref->[42] = 'Huh!';       # autovivify an array in $aref
$href->{"corned beef"} = 0; # autovivify a hash in $href
