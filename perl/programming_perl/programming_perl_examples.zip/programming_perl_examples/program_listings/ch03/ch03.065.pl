my $hexdigit = (0 .. 9, "a" .. "f")[$num & 15];
