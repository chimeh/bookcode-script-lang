$tmp = $global + $constant;
