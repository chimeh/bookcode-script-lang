print 4 | 3;
