$xyz = $x or $y or $z;    # WRONG
