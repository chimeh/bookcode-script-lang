my @combos = ("aa" .. "zz");
