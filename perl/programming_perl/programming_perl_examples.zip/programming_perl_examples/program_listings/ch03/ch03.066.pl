my @z2 = ("01" .. "31");
print $z2[$mday];
