(my $new = $old) =~ s/foo/bar/g;
