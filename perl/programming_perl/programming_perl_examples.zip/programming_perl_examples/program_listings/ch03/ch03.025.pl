1 << 4;     # returns 16
32 >> 4;    # returns 2
