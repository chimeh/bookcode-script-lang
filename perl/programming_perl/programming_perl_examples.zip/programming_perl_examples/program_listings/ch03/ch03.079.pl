($a_or_b ? $a : $b) = $c;  # sets either $a or $b to have the value of $c
