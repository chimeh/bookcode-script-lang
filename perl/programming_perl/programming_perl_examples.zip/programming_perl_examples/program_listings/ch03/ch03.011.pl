$aref->[42]               # an array dereference
$href->{"corned beef"}    # a hash dereference
$sref->(1,2,3)            # a subroutine dereference
