$xyz = $x || $y || $z;
