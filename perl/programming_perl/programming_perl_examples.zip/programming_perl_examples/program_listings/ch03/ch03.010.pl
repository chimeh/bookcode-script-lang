print(($foo & 255) + 1, "\n");   # prints ($foo & 255)+1
