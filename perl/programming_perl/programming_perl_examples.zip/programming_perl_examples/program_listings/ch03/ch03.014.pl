$i = $i++;
print ++$i + $i++;
