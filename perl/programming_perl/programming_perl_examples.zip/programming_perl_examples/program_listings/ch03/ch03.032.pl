-s($file) + 1024   # probably wrong; same as -s($file + 1024)
(-s $file) + 1024  # correct
