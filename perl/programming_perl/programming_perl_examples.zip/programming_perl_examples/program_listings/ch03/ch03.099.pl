unlink("alpha", "beta", "gamma")
        || (gripe(), next LINE);
