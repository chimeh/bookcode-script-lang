printf "I have %d camel%s.\n",
               $n,     $n == 1 ? "" : "s";
