print "-" x 80;                             # print row of dashes
print "\t" x ($tab/8), " " x ($tab%8);      # tab over
