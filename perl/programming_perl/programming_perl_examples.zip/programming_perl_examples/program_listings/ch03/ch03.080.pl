$a % 2 ? $a += 10 : $a += 2        # WRONG
