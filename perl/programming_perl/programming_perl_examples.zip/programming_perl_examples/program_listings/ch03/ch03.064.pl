my @alphabet = ("A" .. "Z");
