next if length < 80;
