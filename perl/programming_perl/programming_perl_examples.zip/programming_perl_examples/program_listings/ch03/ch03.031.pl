next if length() < 80;
next if (length) < 80;
next if 80 > length;
next unless length >= 80;
