$^T = time;
