my $almost = "Fred" . "Flintstone";    # returns FredFlintstone
