(sleep 4) | 3;
