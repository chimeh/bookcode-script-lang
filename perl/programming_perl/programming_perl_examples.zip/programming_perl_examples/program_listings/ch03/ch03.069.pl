use charnames "greek";
my @greek_small =  ("\N{alpha}" .. "\N{omega}");
