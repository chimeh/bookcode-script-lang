scalar(keys(%HASH))
