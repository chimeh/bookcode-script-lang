print <<"odd"
2345
odd
    + 10000;   # prints 12345
