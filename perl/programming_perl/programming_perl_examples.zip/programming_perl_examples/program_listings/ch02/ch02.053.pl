($dev, $ino, undef, undef, $uid, $gid) = stat($file);
