my $comet = 'Haley';  # This is a comment
