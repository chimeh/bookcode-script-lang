unlink @files;      # Delete all files, ignoring errors.
