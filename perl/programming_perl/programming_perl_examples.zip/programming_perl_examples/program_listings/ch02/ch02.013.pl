my $x = 12345;                # integer
my $x = 12345.67;             # floating point
my $x = 6.02e23;              # scientific notation
my $x = 4_294_967_296;        # underline for legibility
my $x = 0377;                 # octal
my $x = 0xffff;               # hexadecimal
my $x = 0b1100_0000;          # binary
