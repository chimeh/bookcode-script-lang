() = funkshun();
