my $single = q!I said, "You said, 'She said it.'"!;

my $double = qq(Can't we get some "good" $variable?);

my $chunk_of_code = q {
    if ($condition) {
        print "Gotcha!";
    }
};
