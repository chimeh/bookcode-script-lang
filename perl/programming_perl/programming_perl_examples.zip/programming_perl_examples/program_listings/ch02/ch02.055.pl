($a, $b, @rest) = split;
my ($a, $b, %rest) = @arg_list;
