$file = <blurch*>;    # scalar context
