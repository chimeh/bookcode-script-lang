$people{ $state, $county } = $census_results;
$people{ join $; => $state, $county } = $census_results;
