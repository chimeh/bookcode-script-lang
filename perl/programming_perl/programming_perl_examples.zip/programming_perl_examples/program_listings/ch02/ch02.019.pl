print "\n";              # Ok, print a newline.
print  \n ;              # WRONG, no interpolative context.
