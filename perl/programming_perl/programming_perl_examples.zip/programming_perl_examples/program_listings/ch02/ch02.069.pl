$hash{ $x, $y, $z }      # a single value
@hash{ $x, $y, $z }      # a slice of three values
