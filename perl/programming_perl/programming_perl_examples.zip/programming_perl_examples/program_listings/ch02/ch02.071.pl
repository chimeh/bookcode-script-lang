$fh = \*STDOUT;
