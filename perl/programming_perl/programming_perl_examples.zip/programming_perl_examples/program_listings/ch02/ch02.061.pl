scalar(@whatever) == $#whatever + 1;
