use v5.14;
use bigrat;
say 1/3 * 6/5 * 5/4;   # prints "1/2"
