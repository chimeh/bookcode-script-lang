my %map = ("red",0xff0000,"green",0x00ff00,"blue",0x0000ff);
