@days = 1 .. 7;
