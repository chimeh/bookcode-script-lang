@files = <*.xml>;
