$stuff = ("one", "two", "three");
