*foo = \$bar;
