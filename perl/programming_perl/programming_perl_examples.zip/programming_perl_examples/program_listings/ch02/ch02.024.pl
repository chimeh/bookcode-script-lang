my @days = qw(Mon Tue Wed Thu Fri);
print STDOUT "hello world\n";
