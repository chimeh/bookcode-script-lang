($file) = <blurch*>;  # list context
