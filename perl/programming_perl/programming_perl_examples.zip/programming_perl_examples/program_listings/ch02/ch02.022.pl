s {foo}   # Replace foo
  {bar};  #    with bar.

tr [a-f]  # Transliterate lowercase hex
   [A-F]; #            to uppercase hex
