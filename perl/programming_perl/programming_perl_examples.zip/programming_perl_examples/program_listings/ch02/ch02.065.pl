my $rec = {
    NAME  => "John Smith",
    RANK  => "Captain",
    SERNO => "951413",
};
