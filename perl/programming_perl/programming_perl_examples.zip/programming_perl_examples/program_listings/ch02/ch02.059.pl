@days + 0;      # implicitly force @days into scalar context
scalar(@days)   # explicitly force @days into scalar context
