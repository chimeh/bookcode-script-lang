Useless use of a constant in void context in myprog line 123;
