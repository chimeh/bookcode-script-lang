*foo = *bar;
