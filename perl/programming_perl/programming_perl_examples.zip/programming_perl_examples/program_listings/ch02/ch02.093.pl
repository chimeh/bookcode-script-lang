@files = glob("*.xml");
