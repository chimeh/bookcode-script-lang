chmod 0644, <*.c>;
