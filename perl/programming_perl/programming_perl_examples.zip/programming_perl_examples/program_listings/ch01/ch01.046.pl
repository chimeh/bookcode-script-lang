$a = 123;
$b = 3;
say $a * $b;     # prints 369
say $a x $b;     # prints 123123123
