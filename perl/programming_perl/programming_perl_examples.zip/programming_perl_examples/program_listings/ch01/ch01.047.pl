say $a . " is equal to " . $b . ".";    # dot operator
say $a, " is equal to ", $b, ".";       # list
say "$a is equal to $b.";               # interpolation
