my $camels = "123";
print $camels + 1, "\n";
