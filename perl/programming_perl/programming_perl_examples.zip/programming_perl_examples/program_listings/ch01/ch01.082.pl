/\bFred\b/
