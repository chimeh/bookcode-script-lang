sort LIST
