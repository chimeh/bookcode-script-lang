Adam's wife is Eve.
