last LINE if $line =~ /^>/;
