my $fido = Camel->new("Amelia");
if (not $fido) { die "dead camel"; }
$fido->saddle();
