open(GRADES, "<:utf8", "grades")  || die "Can't open file grades: $!\n";
