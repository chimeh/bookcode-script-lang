package Camel;
our $fido = &fetch();
