lvalue operator= expression
