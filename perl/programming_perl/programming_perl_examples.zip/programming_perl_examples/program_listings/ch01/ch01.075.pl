s/IBM/lenovo/;
