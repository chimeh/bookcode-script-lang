my $phrase = "Howdy, world!\n";       # Create a variable.
print $phrase;                        # Print the variable.
