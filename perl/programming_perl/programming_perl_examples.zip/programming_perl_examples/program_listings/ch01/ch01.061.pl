if ($debug_level > 0) {
    # Something has gone wrong.  Tell the user.
    say "Debug: Danger, Will Robinson, danger!";
    say "Debug: Answer was '54', expected '42'.";
}
