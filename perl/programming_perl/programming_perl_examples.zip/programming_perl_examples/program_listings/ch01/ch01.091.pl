print reverse sort map {lc} keys %hash;
