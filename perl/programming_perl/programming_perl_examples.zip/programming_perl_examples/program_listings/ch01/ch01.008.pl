my ($potato, $lift, $tennis, $pipe) = @home;
