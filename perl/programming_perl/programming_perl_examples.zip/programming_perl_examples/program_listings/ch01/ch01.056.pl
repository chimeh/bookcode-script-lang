chop($number = <STDIN>);
