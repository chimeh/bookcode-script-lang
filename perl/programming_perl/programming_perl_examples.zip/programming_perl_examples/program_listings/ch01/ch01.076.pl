my ($good, $bad, $ugly) = split(/,/, "vi,emacs,teco");
