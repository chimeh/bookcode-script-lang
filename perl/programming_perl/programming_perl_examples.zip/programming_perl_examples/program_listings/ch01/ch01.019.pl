my $fido = Camel->new("Amelia");
