if (/Windows 7/) { print "Time to upgrade?\n" }
