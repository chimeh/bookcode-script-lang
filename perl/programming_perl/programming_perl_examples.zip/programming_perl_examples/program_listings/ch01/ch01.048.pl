say "-" x $scrwid;
