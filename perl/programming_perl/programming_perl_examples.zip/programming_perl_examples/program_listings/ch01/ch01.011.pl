my %longday = ("Sun", "Sunday", "Mon", "Monday", "Tue", "Tuesday",
               "Wed", "Wednesday", "Thu", "Thursday", "Fri",
               "Friday", "Sat", "Saturday");
