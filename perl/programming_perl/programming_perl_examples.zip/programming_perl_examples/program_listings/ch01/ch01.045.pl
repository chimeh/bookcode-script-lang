$a = 123;
$b = 456;
say $a + $b;     # prints 579
say $a . $b;     # prints 123456
