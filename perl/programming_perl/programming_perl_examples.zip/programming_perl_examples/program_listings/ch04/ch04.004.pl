s/java/perl/ for @resumes;
say "field: $_" foreach split /:/, $dataline;
