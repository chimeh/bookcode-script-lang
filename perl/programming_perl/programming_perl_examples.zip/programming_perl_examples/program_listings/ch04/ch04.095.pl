# WARNING: Changes are temporary to this dynamic scope.
local $Some_Global = $Some_Global;
