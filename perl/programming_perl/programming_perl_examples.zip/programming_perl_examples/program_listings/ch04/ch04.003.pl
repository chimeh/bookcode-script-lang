$expression++ while -e "$file$expression";
kiss("me") until $I_die;
