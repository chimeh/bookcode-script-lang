do { my $_ = EXPR; ... }
