when ("foo" or "bar") { ... }
