my $foo = <STDIN>;
