when ([qw(foo bar)] || /^baz/) { ... }
