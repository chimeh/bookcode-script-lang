my $nose;
our $House;
state $troopers = 0;
local $TV_channel;
