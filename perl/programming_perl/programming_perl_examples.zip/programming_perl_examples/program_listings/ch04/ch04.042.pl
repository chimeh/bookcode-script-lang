next LINE if /^#/;      # discard comments
