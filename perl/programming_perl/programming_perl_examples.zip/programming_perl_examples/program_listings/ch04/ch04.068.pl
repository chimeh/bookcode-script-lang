goto $data;
ABC: $foo++; goto end;
DEF: $bar++; goto end;
XYZ: $baz++; goto end;
end:
