my $foo, $bar = 1;              # WRONG
