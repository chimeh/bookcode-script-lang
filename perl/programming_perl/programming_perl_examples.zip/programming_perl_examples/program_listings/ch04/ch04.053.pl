do {{
    next if $x == $y;
    # do something here
}} until $x++ > $z;
