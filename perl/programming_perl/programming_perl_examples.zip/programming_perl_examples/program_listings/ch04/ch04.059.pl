for my $_ (@answers) {
    say "Life, the Universe, and Everything!" when 42;
}
