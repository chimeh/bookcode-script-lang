my $foo;
$bar = 1;
