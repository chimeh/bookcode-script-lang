$value = $color_map{ lc $user_color_preference } || 0x000000;
