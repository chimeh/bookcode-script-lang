@transformed = map { ... } @input;  # WRONG: syntax error
