{
    local $^W = 0;
    ...
}
