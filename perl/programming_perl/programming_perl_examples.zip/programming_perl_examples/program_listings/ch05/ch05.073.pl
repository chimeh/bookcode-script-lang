42 =~ /^[:digit:]$/         # WRONG
