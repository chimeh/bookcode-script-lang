"exasperate" =~ /e(.*?)e/   #  $1 now "xasp"
