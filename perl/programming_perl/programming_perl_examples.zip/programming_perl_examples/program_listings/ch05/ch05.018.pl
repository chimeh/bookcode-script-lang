if ($song !~ /words/) {
    say qq/"$song" appears to be a song without words./;
}
