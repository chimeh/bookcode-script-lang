(?> \R
  | \p{Grapheme_Base}   \p{Grapheme_Extend}*
  | \p{Grapheme_Extend}+
  | .
)
