if (($key,$value) = /(\w+): (.*)/) { ... }
