"exasperate" =~ /.*e(.*?)e/   #  $1 now "rat"
