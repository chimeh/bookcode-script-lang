$tales_of_Rohan =~ s/Éo\Kmer/wyn/g; # rewriting history
