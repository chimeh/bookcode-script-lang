$message =~ tr/A-Za-z/N-ZA-Mn-za-m/;    # rot13 encryption.
