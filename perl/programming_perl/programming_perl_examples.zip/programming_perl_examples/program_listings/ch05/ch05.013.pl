say "matches" if $somestring =~ m/$somepattern/;
