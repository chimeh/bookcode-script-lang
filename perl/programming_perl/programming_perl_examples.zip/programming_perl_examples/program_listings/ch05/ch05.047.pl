$lotr = $hobbit =~ s/Bilbo/Frodo/gr;
