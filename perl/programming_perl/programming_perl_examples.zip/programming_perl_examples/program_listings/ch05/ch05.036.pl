%hash = $string =~ /(\w+)=(\w+)/g;
