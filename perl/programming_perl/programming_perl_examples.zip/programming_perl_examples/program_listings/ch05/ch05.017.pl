if ((lc $magic_hat->fetch_contents->as_string) =~ /rabbit/) {
    say "Nyaa, what's up doc?";
}
else {
    say "That trick never works!";
}
