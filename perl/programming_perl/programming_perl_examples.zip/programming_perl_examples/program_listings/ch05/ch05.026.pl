dup word 'that' at paragraph 150
