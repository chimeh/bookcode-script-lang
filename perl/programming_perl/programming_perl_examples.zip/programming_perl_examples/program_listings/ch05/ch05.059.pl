say "Drogo" =~ tr/Dg/Fd/r;   # Drogo -> Frodo
