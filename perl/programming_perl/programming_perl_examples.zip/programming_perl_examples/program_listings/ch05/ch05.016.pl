"onshore" =~ s/on/off/;      # WRONG: compile-time error
