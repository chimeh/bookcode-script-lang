s/revision|version|release/\u$&/g;  # Use | to mean "or" in a pattern
