s (egg)   <larva>;
s {larva} {pupa};
s [pupa]  /imago/;
