say "matches" if $somestring =~ $somepattern;
