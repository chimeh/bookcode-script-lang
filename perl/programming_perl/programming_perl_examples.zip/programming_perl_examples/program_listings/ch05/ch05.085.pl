Found a B at 0
Found a B at 3
Found a B at 6
