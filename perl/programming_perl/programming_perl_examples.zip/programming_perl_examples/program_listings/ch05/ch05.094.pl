s/^(\S+) (\S+)/$2 $1/;  # Swap first two words
