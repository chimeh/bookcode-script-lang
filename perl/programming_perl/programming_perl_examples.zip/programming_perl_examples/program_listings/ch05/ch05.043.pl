say "Déagol's ring!" =~ s/D/Sm/r;  # prints "Sméagol's ring!"
