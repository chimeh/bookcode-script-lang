$foo = "bar";
/$foo$/;
