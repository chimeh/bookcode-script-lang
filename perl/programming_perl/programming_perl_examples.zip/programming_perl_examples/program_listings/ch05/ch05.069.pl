use re "/a";
