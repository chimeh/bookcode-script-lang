tr/AAA/XYZ/
