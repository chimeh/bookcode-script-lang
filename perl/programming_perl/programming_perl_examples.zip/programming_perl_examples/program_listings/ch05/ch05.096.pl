"foofoobar" =~ /^(foo)\1bar$/               # backref
