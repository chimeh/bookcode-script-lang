s/version ([0-9.]+)/the $Names{$1} release/g;
