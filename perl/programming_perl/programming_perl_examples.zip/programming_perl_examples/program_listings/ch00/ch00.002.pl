given ($item) {
  when (/a/)   { say "Matched an a"  }
  when (/bee/) { say "Matched a bee" }
}
